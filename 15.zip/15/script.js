let arr = [];
for (let i = 1; i <= 16; i++) {
    let randomNumber = Math.floor(Math.random() * 16) + 1;
    while (arr.includes(randomNumber)) {
        randomNumber = Math.floor(Math.random() * 16) + 1;
    }
    arr.push(randomNumber);
}
console.log(arr);
for (let i = 0; i <= 15; i++) {
    document.getElementById("d" + parseInt(i + 1)).innerHTML = arr[i];
}
var index;
for (let i = 0; i < arr.length; i++) {
    if (arr[i] == 16) {
        index = i;
        break;
    }
}
console.log(index);
document.getElementById("d" + parseInt(index + 1)).style.visibility = "hidden";
var width = window.innerWidth;
console.log(width + "px");
var mov;
if (width <= 600) {
    mov = 74;
} else {
    mov = 154;
}
window.addEventListener('resize', function () {
    var width = window.innerWidth;
    console.log(width + "px");
    if (width <= 600) {
        mov = 54;
    } else {
        mov = 154;
    }
});
function rematch() {
    location.reload();
}
function delay(d) {
    document.getElementById("d" + d).style.visibility = "hidden";
    setTimeout(function () {
        document.getElementById("d" + d).style.transform = "translateX(0)";
        document.getElementById("d" + d).style.transform = "translateY(0)";
    }, 300);
}
function dv(v) {
    setTimeout(function () {
        document.getElementById("d" + v).style.visibility = "visible";
    }, 150);

}

function cor() {
    if (document.getElementById("d1").innerHTML == 1
        && document.getElementById("d2").innerHTML == 5
        && document.getElementById("d3").innerHTML == 9
        && document.getElementById("d4").innerHTML == 13
        && document.getElementById("d5").innerHTML == 2
        && document.getElementById("d6").innerHTML == 6
        && document.getElementById("d7").innerHTML == 10
        && document.getElementById("d8").innerHTML == 14
        && document.getElementById("d9").innerHTML == 3
        && document.getElementById("d10").innerHTML == 7
        && document.getElementById("d11").innerHTML == 11
        && document.getElementById("d12").innerHTML == 15
        && document.getElementById("d13").innerHTML == 4
        && document.getElementById("d14").innerHTML == 8
        && document.getElementById("d15").innerHTML == 12) {

        document.getElementById("all").style.visibility = "visible";
    }
}

function t1() {
    if (document.getElementById("d5").style.visibility == "hidden") {
        document.getElementById("d1").style.transform = "translateX(" + mov + "px)";
        document.getElementById("d5").innerHTML = document.getElementById("d1").innerHTML;
        dv(5);
    } else if (document.getElementById("d2").style.visibility == "hidden") {
        document.getElementById("d1").style.transform = "translateY(" + mov + "px)";
        document.getElementById("d2").innerHTML = document.getElementById("d1").innerHTML;
        dv(2);
    } else {
        dv(1);
    }
    delay(1);
    cor();
}
function t2() {
    if (document.getElementById("d1").style.visibility == "hidden") {
        document.getElementById("d2").style.transform = "translateY(-" + mov + "px)";
        document.getElementById("d1").innerHTML = document.getElementById("d2").innerHTML;
        dv(1);
    } else if (document.getElementById("d3").style.visibility == "hidden") {
        document.getElementById("d2").style.transform = "translateY(" + mov + "px)";
        document.getElementById("d3").innerHTML = document.getElementById("d2").innerHTML;
        dv(3);
    }
    else if (document.getElementById("d6").style.visibility == "hidden") {
        document.getElementById("d2").style.transform = "translateX(" + mov + "px)";
        document.getElementById("d6").innerHTML = document.getElementById("d2").innerHTML;
        dv(6);
    } else {
        dv(2);
    }
    delay(2); cor();

}
function t3() {
    if (document.getElementById("d2").style.visibility == "hidden") {
        document.getElementById("d3").style.transform = "translateY(-" + mov + "px)";
        document.getElementById("d2").innerHTML = document.getElementById("d3").innerHTML;
        dv(2);

    } else if (document.getElementById("d4").style.visibility == "hidden") {
        document.getElementById("d3").style.transform = "translateY(" + mov + "px)";
        document.getElementById("d4").innerHTML = document.getElementById("d3").innerHTML;
        dv(4);
    }
    else if (document.getElementById("d7").style.visibility == "hidden") {
        document.getElementById("d3").style.transform = "translateX(" + mov + "px)";
        document.getElementById("d7").innerHTML = document.getElementById("d3").innerHTML;
        dv(7);
    } else {
        dv(3);
    }
    delay(3); cor();

}
function t4() {
    if (document.getElementById("d3").style.visibility == "hidden") {
        document.getElementById("d4").style.transform = "translateY(-" + mov + "px)";
        document.getElementById("d3").innerHTML = document.getElementById("d4").innerHTML;
        dv(3);
    } else if (document.getElementById("d8").style.visibility == "hidden") {
        document.getElementById("d4").style.transform = "translateX(" + mov + "px)";
        document.getElementById("d8").innerHTML = document.getElementById("d4").innerHTML;
        dv(8);
    } else {
        dv(4);
    }
    delay(4); cor();

}
function t5() {
    if (document.getElementById("d1").style.visibility == "hidden") {
        document.getElementById("d5").style.transform = "translateX(-" + mov + "px)";
        document.getElementById("d1").innerHTML = document.getElementById("d5").innerHTML;
        dv(1);

    } else if (document.getElementById("d6").style.visibility == "hidden") {
        document.getElementById("d5").style.transform = "translateY(" + mov + "px)";
        document.getElementById("d6").innerHTML = document.getElementById("d5").innerHTML;
        dv(6);
    }
    else if (document.getElementById("d9").style.visibility == "hidden") {
        document.getElementById("d5").style.transform = "translateX(" + mov + "px)";
        document.getElementById("d9").innerHTML = document.getElementById("d5").innerHTML;
        dv(9);
    } else {
        dv(5);
    }
    delay(5); cor();

}
function t6() {
    if (document.getElementById("d2").style.visibility == "hidden") {
        document.getElementById("d6").style.transform = "translateX(-" + mov + "px)";
        document.getElementById("d2").innerHTML = document.getElementById("d6").innerHTML;
        dv(2);

    } else if (document.getElementById("d7").style.visibility == "hidden") {
        document.getElementById("d6").style.transform = "translateY(" + mov + "px)";
        document.getElementById("d7").innerHTML = document.getElementById("d6").innerHTML;
        dv(7);
    }
    else if (document.getElementById("d10").style.visibility == "hidden") {
        document.getElementById("d6").style.transform = "translateX(" + mov + "px)";
        document.getElementById("d10").innerHTML = document.getElementById("d6").innerHTML;
        dv(10);

    } else if (document.getElementById("d5").style.visibility == "hidden") {
        document.getElementById("d6").style.transform = "translateY(-" + mov + "px)";
        document.getElementById("d5").innerHTML = document.getElementById("d6").innerHTML;
        dv(5);
    } else {
        dv(6);
    }
    delay(6); cor();

}
function t7() {
    if (document.getElementById("d3").style.visibility == "hidden") {
        document.getElementById("d7").style.transform = "translateX(-" + mov + "px)";
        document.getElementById("d3").innerHTML = document.getElementById("d7").innerHTML;
        dv(3);

    } else if (document.getElementById("d8").style.visibility == "hidden") {
        document.getElementById("d7").style.transform = "translateY(" + mov + "px)";
        document.getElementById("d8").innerHTML = document.getElementById("d7").innerHTML;
        dv(8);
    }
    else if (document.getElementById("d11").style.visibility == "hidden") {
        document.getElementById("d7").style.transform = "translateX(" + mov + "px)";
        document.getElementById("d11").innerHTML = document.getElementById("d7").innerHTML;
        dv(11);

    } else if (document.getElementById("d6").style.visibility == "hidden") {
        document.getElementById("d7").style.transform = "translateY(-" + mov + "px)";
        document.getElementById("d6").innerHTML = document.getElementById("d7").innerHTML;
        dv(6);
    } else {
        dv(7);
    }
    delay(7); cor();

}
function t8() {
    if (document.getElementById("d4").style.visibility == "hidden") {
        document.getElementById("d8").style.transform = "translateX(-" + mov + "px)";
        document.getElementById("d4").innerHTML = document.getElementById("d8").innerHTML;
        dv(4);

    }
    else if (document.getElementById("d12").style.visibility == "hidden") {
        document.getElementById("d8").style.transform = "translateX(" + mov + "px)";
        document.getElementById("d12").innerHTML = document.getElementById("d8").innerHTML;
        dv(12);

    } else if (document.getElementById("d7").style.visibility == "hidden") {
        document.getElementById("d8").style.transform = "translateY(-" + mov + "px)";
        document.getElementById("d7").innerHTML = document.getElementById("d8").innerHTML;
        dv(7);
    } else {
        dv(8);
    }
    delay(8); cor();

}
function t9() {
    if (document.getElementById("d5").style.visibility == "hidden") {
        document.getElementById("d9").style.transform = "translateX(-" + mov + "px)";
        document.getElementById("d5").innerHTML = document.getElementById("d9").innerHTML;
        dv(5);

    }
    else if (document.getElementById("d13").style.visibility == "hidden") {
        document.getElementById("d9").style.transform = "translateX(" + mov + "px)";
        document.getElementById("d13").innerHTML = document.getElementById("d9").innerHTML;
        dv(13);

    } else if (document.getElementById("d10").style.visibility == "hidden") {
        document.getElementById("d9").style.transform = "translateY(" + mov + "px)";
        document.getElementById("d10").innerHTML = document.getElementById("d9").innerHTML;
        dv(10);
    } else {
        dv(9);
    }
    delay(9); cor();

}

function t10() {
    if (document.getElementById("d6").style.visibility == "hidden") {
        document.getElementById("d10").style.transform = "translateX(-" + mov + "px)";
        document.getElementById("d6").innerHTML = document.getElementById("d10").innerHTML;
        dv(6);
    } else if (document.getElementById("d11").style.visibility == "hidden") {
        document.getElementById("d10").style.transform = "translateY(" + mov + "px)";
        document.getElementById("d11").innerHTML = document.getElementById("d10").innerHTML;
        dv(11);
    }
    else if (document.getElementById("d14").style.visibility == "hidden") {
        document.getElementById("d10").style.transform = "translateX(" + mov + "px)";
        document.getElementById("d14").innerHTML = document.getElementById("d10").innerHTML;
        dv(14);
    } else if (document.getElementById("d9").style.visibility == "hidden") {
        document.getElementById("d10").style.transform = "translateY(-" + mov + "px)";
        document.getElementById("d9").innerHTML = document.getElementById("d10").innerHTML;
        dv(9);
    } else {
        dv(10);
    }
    delay(10); cor();

}
function t11() {
    if (document.getElementById("d7").style.visibility == "hidden") {
        document.getElementById("d11").style.transform = "translateX(-" + mov + "px)";
        document.getElementById("d7").innerHTML = document.getElementById("d11").innerHTML;
        dv(7);
    } else if (document.getElementById("d12").style.visibility == "hidden") {
        document.getElementById("d11").style.transform = "translateY(" + mov + "px)";
        document.getElementById("d12").innerHTML = document.getElementById("d11").innerHTML;
        dv(12);
    }
    else if (document.getElementById("d15").style.visibility == "hidden") {
        document.getElementById("d11").style.transform = "translateX(" + mov + "px)";
        document.getElementById("d15").innerHTML = document.getElementById("d11").innerHTML;
        dv(15);
    } else if (document.getElementById("d10").style.visibility == "hidden") {
        document.getElementById("d11").style.transform = "translateY(-" + mov + "px)";
        document.getElementById("d10").innerHTML = document.getElementById("d11").innerHTML;
        dv(10);
    } else {
        dv(11);
    }
    delay(11); cor();

}
function t12() {
    if (document.getElementById("d8").style.visibility == "hidden") {
        document.getElementById("d12").style.transform = "translateX(-" + mov + "px)";
        document.getElementById("d8").innerHTML = document.getElementById("d12").innerHTML;
        dv(8);
    }
    else if (document.getElementById("d16").style.visibility == "hidden") {
        document.getElementById("d12").style.transform = "translateX(" + mov + "px)";
        document.getElementById("d16").innerHTML = document.getElementById("d12").innerHTML;
        dv(16);
    } else if (document.getElementById("d11").style.visibility == "hidden") {
        document.getElementById("d11").innerHTML = document.getElementById("d12").innerHTML;
        document.getElementById("d12").style.transform = "translateY(-" + mov + "px)";
        dv(11);
    } else {
        dv(12);
    }
    delay(12); cor();

}

function t13() {
    if (document.getElementById("d9").style.visibility == "hidden") {
        document.getElementById("d13").style.transform = "translateX(-" + mov + "px)";
        document.getElementById("d9").innerHTML = document.getElementById("d13").innerHTML;
        dv(9);
    }
    else if (document.getElementById("d14").style.visibility == "hidden") {
        document.getElementById("d13").style.transform = "translateY(" + mov + "px)";
        document.getElementById("d14").innerHTML = document.getElementById("d13").innerHTML;
        dv(14);
    } else {
        dv(13);
    }
    delay(13); cor();

}

function t14() {
    if (document.getElementById("d13").style.visibility == "hidden") {
        document.getElementById("d14").style.transform = "translateY(-" + mov + "px)";
        document.getElementById("d13").innerHTML = document.getElementById("d14").innerHTML;
        dv(13);
    }
    else if (document.getElementById("d15").style.visibility == "hidden") {
        document.getElementById("d14").style.transform = "translateY(" + mov + "px)";
        document.getElementById("d15").innerHTML = document.getElementById("d14").innerHTML;
        dv(15);
    } else if (document.getElementById("d10").style.visibility == "hidden") {
        document.getElementById("d14").style.transform = "translateX(-" + mov + "px)";
        document.getElementById("d10").innerHTML = document.getElementById("d14").innerHTML;
        dv(10);
    } else {
        dv(14);
    }
    delay(14); cor();

}

function t15() {
    if (document.getElementById("d14").style.visibility == "hidden") {
        document.getElementById("d15").style.transform = "translateY(-" + mov + "px)";
        document.getElementById("d14").innerHTML = document.getElementById("d15").innerHTML;
        dv(14);
    }
    else if (document.getElementById("d16").style.visibility == "hidden") {
        document.getElementById("d15").style.transform = "translateY(" + mov + "px)";
        document.getElementById("d16").innerHTML = document.getElementById("d15").innerHTML;
        dv(16);
    } else if (document.getElementById("d11").style.visibility == "hidden") {
        document.getElementById("d15").style.transform = "translateX(-" + mov + "px)";
        document.getElementById("d11").innerHTML = document.getElementById("d15").innerHTML;
        dv(11);
    } else {
        dv(15);
    }
    delay(15); cor();

}
function t16() {
    if (document.getElementById("d15").style.visibility == "hidden") {
        document.getElementById("d16").style.transform = "translateY(-" + mov + "px)";
        document.getElementById("d15").innerHTML = document.getElementById("d16").innerHTML;
        dv(15);
    }
    else if (document.getElementById("d12").style.visibility == "hidden") {
        document.getElementById("d16").style.transform = "translateX(-" + mov + "px)";
        document.getElementById("d12").innerHTML = document.getElementById("d16").innerHTML;
        dv(12);
    } else {
        dv(16);
    }
    delay(16); cor();

}


