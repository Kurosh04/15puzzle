var d1 = Math.floor(Math.random() * 16) + 1;
var d2 = Math.floor(Math.random() * 16) + 1;
var d3 = Math.floor(Math.random() * 16) + 1;
var d4 = Math.floor(Math.random() * 16) + 1;
var d5 = Math.floor(Math.random() * 16) + 1;
var d6 = Math.floor(Math.random() * 16) + 1;
var d7 = Math.floor(Math.random() * 16) + 1;
var d8 = Math.floor(Math.random() * 16) + 1;
var d9 = Math.floor(Math.random() * 16) + 1;
var d10 = Math.floor(Math.random() * 16) + 1;
var d11 = Math.floor(Math.random() * 16) + 1;
var d12 = Math.floor(Math.random() * 16) + 1;
var d13 = Math.floor(Math.random() * 16) + 1;
var d14 = Math.floor(Math.random() * 16) + 1;
var d15 = Math.floor(Math.random() * 16) + 1;
var d16 = Math.floor(Math.random() * 16) + 1;
while (true) {
    if (d2 == d1) {
        var d2 = Math.floor(Math.random() * 16) + 1;
    } else {
        break;
    }
}
while (true) {
    if (d3 == d1 || d3 == d2) {
        var d2 = Math.floor(Math.random() * 16) + 1;
    } else {
        break;
    }
}
while (true) {
    if (d4 == d1 || d4 == d2 || d4 == d3) {
        var d4 = Math.floor(Math.random() * 16) + 1;
    } else {
        break;
    }
}
while (true) {
    if (d5 == d1 || d5 == d2 || d5 == d3 || d5 == d4) {
        var d5 = Math.floor(Math.random() * 16) + 1;
    } else {
        break;
    }
}
while (true) {
    if (d6 == d1 || d6 == d2 || d6 == d3 || d6 == d4 || d6 == d5) {
        var d6 = Math.floor(Math.random() * 16) + 1;
    } else {
        break;
    }
}

while (true) {
    if (d7 == d1 || d7 == d2 || d7 == d3 || d7 == d4 || d7 == d5 || d7 == d6) {
        var d7 = Math.floor(Math.random() * 16) + 1;
    } else {
        break;
    }
}

while (true) {
    if (d8 == d1 || d8 == d2 || d8 == d3 || d8 == d4 || d8 == d5 || d8 == d6 || d8 == d7) {
        var d8 = Math.floor(Math.random() * 16) + 1;
    } else {
        break;
    }
}
while (true) {
    if (d9 == d1 || d9 == d2 || d9 == d3 || d9 == d4 || d9 == d5 || d9 == d6 || d9 == d7 || d9 == d8) {
        var d9 = Math.floor(Math.random() * 16) + 1;
    } else {
        break;
    }
}
while (true) {
    if (d10 == d1 || d10 == d2 || d10 == d3 || d10 == d4 || d10 == d5 || d10 == d6 || d10 == d7 || d10 == d8 || d10 == d9) {
        var d10 = Math.floor(Math.random() * 16) + 1;
    } else {
        break;
    }
}
while (true) {
    if (d11 == d1 || d11 == d2 || d11 == d3 || d11 == d4 || d11 == d5 || d11 == d6 || d11 == d7 || d11 == d8 || d11 == d9 || d11 == d10) {
        var d11 = Math.floor(Math.random() * 16) + 1;
    } else {
        break;
    }
}
while (true) {
    if (d12 == d1 || d12 == d2 || d12 == d3 || d12 == d4 || d12 == d5 || d12 == d6 || d12 == d7 || d12 == d8 || d12 == d9 || d12 == d10 || d12 == d11) {
        var d12 = Math.floor(Math.random() * 16) + 1;
    } else {
        break;
    }
}
while (true) {
    if (d13 == d1 || d13 == d2 || d13 == d3 || d13 == d4 || d13 == d5 || d13 == d6 || d13 == d7 || d13 == d8 || d13 == d9 || d13 == d10 || d13 == d11 || d13 == d12) {
        var d13 = Math.floor(Math.random() * 16) + 1;
    } else {
        break;
    }
}
while (true) {
    if (d14 == d1 || d14 == d2 || d14 == d3 || d14 == d4 || d14 == d5 || d14 == d6 || d14 == d7 || d14 == d8 || d14 == d9 || d14 == d10 || d14 == d11 || d14 == d12 || d14 == d13) {
        var d14 = Math.floor(Math.random() * 16) + 1;
    } else {
        break;
    }
}
while (true) {
    if (d15 == d1 || d15 == d2 || d15 == d3 || d15 == d4 || d15 == d5 || d15 == d6 || d15 == d7 || d15 == d8 || d15 == d9 || d15 == d10 || d15 == d11 || d15 == d12 || d15 == d13 || d15 == d14) {
        var d15 = Math.floor(Math.random() * 16) + 1;
    } else {
        break;
    }
}
while (true) {
    if (d16 == d1 || d16 == d2 || d16 == d3 || d16 == d4 || d16 == d5 || d16 == d6 || d16 == d7 || d16 == d8 || d16 == d9 || d16 == d10 || d16 == d11 || d16 == d12 || d16 == d13 || d16 == d14 || d16 == d15) {
        var d16 = Math.floor(Math.random() * 16) + 1;
    } else {
        break;
    }
}
document.getElementById("d1").innerHTML = d1;
document.getElementById("d2").innerHTML = d2;
document.getElementById("d3").innerHTML = d3;
document.getElementById("d4").innerHTML = d4;
document.getElementById("d5").innerHTML = d5;
document.getElementById("d6").innerHTML = d6;
document.getElementById("d7").innerHTML = d7;
document.getElementById("d8").innerHTML = d8;
document.getElementById("d9").innerHTML = d9;
document.getElementById("d10").innerHTML = d10;
document.getElementById("d11").innerHTML = d11;
document.getElementById("d12").innerHTML = d12;
document.getElementById("d13").innerHTML = d13;
document.getElementById("d14").innerHTML = d14;
document.getElementById("d15").innerHTML = d15;
document.getElementById("d16").innerHTML = d16;

// if(d1 == "16"){
//     document.getElementById("d1").style.display = "none";
// }